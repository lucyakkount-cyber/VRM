  <template>
    <div class="relative w-full h-screen bg-[#0b0d12] overflow-hidden">
      <!-- VRM Canvas -->
      <canvas ref="canvasRef" class="absolute inset-0 w-full h-full"></canvas>

      <!-- Chat Composer -->
      <div
        class="absolute bottom-[30px] left-1/2 -translate-x-1/2 w-[calc(100%-40px)] max-w-[1000px]"
      >
        <form
          class="bg-white dark:bg-gray-800 shadow-md rounded-2xl p-3 grid grid-cols-[auto_1fr_auto] gap-2"
          @submit.prevent="sendMessage"
        >
          <button
            type="button"
            class="flex items-center justify-center w-10 h-10 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
          >
            <PlusIcon class="w-6 h-6 text-gray-600 dark:text-gray-300" />
          </button>

          <textarea
            ref="textareaRef"
            v-model="userInput"
            rows="1"
            placeholder="Ask anything..."
            class="flex-1 resize-none overflow-hidden bg-transparent focus:outline-none px-2 py-1 text-gray-900 dark:text-gray-100"
            @input="autoResize"
          ></textarea>

          <div class="flex items-center gap-2">
            <button
              type="button"
              @click="toggleRecording"
              class="flex items-center justify-center w-10 h-10 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
              :class="{ 'bg-red-500 text-white': isRecording }"
            >
              <MicrophoneIcon class="w-6 h-6" />
            </button>

            <button
              type="submit"
              class="flex items-center justify-center w-10 h-10 rounded-full bg-blue-600 text-white hover:bg-blue-700"
            >
              <PaperAirplaneIcon class="w-5 h-5" />
            </button>
          </div>
        </form>
      </div>

      <!-- Animation Debug Panel (Optional) -->
      <div class="absolute top-4 right-4 bg-black bg-opacity-50 text-white p-2 rounded text-xs">
        <div>Current Expression: {{ currentExpression }}</div>
        <div>Current Gesture: {{ currentGesture }}</div>
        <div>Animation Queue: {{ animationQueue.length }}</div>
      </div>

      <audio ref="audioRef" class="hidden" controls></audio>
    </div>
  </template>

  <script setup>
  import { ref, onMounted, onBeforeUnmount } from 'vue'
  import * as THREE from 'three'
  import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js'
  import { FBXLoader } from 'three/examples/jsm/loaders/FBXLoader.js'
  import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js'
  import { VRMUtils, VRMLoaderPlugin } from '@pixiv/three-vrm'
  import { PlusIcon, PaperAirplaneIcon, MicrophoneIcon } from '@heroicons/vue/24/solid'
  import yaml from 'js-yaml'

  import axios from 'axios'
  import { GoogleGenAI } from '@google/genai'

  // --- Enhanced Animation System ---
  const currentExpression = ref('neutral')
  const currentGesture = ref('none')
  const animationQueue = ref([])

  // --- Available expressions and gestures ---
  const EXPRESSIONS = {
    neutral: 0,
    happy: ['happy', 'joy'],
    sad: ['sad', 'sorrow'],
    angry: ['angry', 'fury'],
    surprised: ['surprised', 'shocked'],
    excited: ['excited', 'happy'],
    confused: ['confused', 'sad'],
    smirk: ['smirk', 'happy'],
    laugh: ['happy', 'joy'],
    embarrassed: ['blink', 'happy'],
    determined: ['angry'],
    worried: ['sad', 'blink'],
    curious: ['surprised'],
    sleepy: ['relaxed', 'blink'],
    mischievous: ['smirk', 'wink']
  }

  const GESTURES = {
    none: null,
    point: 'point',
    handWave: 'wave',
    shrug: 'shrug',
    leanIn: 'leanIn',
    crossArms: 'crossArms',
    handToHeart: 'heartGesture',
    thumbsUp: 'thumbsUp',
    facepalm: 'facepalm',
    handToHip: 'handToHip',
    stretch: 'stretch',
    clap: 'clap',
    think: 'thinkGesture'
  }

  // --- Web Audio API setup ---
  const audioCtx = ref(null)
  const analyser = ref(null)
  let sourceNode = null
  let mouthRaf = null
  let blinkInterval = null
  let gestureTimeout = null

  // --- Google AI Client ---
  let charConfig = {}
  async function loadConfig() {
    try {
      const res = await fetch('/character_config.yaml')
      const text = await res.text()
      charConfig = yaml.load(text)
      console.log('YAML loaded:', charConfig)
    } catch (e) {
      console.error('[ERROR] Could not load YAML config:', e)
    }
  }

  const gptClient = new GoogleGenAI({
    apiKey: charConfig.OPENAI_API_KEY || 'AIzaSyCYkivW_PQEE3ayBSYTXw1mtnQiDMau7GM',
  })

  // --- VRM setup ---
  const canvasRef = ref(null)
  const audioRef = ref(null)
  const textareaRef = ref(null)
  const userInput = ref('')
  let renderer, scene, camera, controls, vrm, clock, animationFrameId
  let currentMixer = null
  let currentAnimationAction = null
  let idleAnimation = null
  let gestureAnimations = {}

  // --- Enhanced Mixamo to VRM bone mapping ---
  const mixamoVRMRigMap = {
    mixamorigHips: 'hips',
    mixamorigSpine: 'spine',
    mixamorigSpine1: 'chest',
    mixamorigSpine2: 'upperChest',
    mixamorigNeck: 'neck',
    mixamorigHead: 'head',
    mixamorigLeftShoulder: 'leftShoulder',
    mixamorigLeftArm: 'leftUpperArm',
    mixamorigLeftForeArm: 'leftLowerArm',
    mixamorigLeftHand: 'leftHand',
    mixamorigRightShoulder: 'rightShoulder',
    mixamorigRightArm: 'rightUpperArm',
    mixamorigRightForeArm: 'rightLowerArm',
    mixamorigRightHand: 'rightHand',
    mixamorigLeftUpLeg: 'leftUpperLeg',
    mixamorigLeftLeg: 'leftLowerLeg',
    mixamorigLeftFoot: 'leftFoot',
    mixamorigRightUpLeg: 'rightUpperLeg',
    mixamorigRightLeg: 'rightLowerLeg',
    mixamorigRightFoot: 'rightFoot',
    mixamorigLeftToeBase: 'leftToes',
    mixamorigRightToeBase: 'rightToes',
  }

  onMounted(async () => {
    await loadConfig()

    audioCtx.value = new (window.AudioContext || window.webkitAudioContext)()

    renderer = new THREE.WebGLRenderer({ antialias: true, canvas: canvasRef.value, alpha: true })
    renderer.setSize(window.innerWidth, window.innerHeight)
    renderer.setPixelRatio(window.devicePixelRatio)
    renderer.shadowMap.enabled = true
    renderer.shadowMap.type = THREE.PCFSoftShadowMap

    scene = new THREE.Scene()
    camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 100)
    camera.position.set(0, 1.4, 2.2)

    // Enhanced lighting
    scene.add(new THREE.AmbientLight(0x404040, 0.4))
    const mainLight = new THREE.DirectionalLight(0xffffff, 0.8)
    mainLight.position.set(5, 10, 5)
    mainLight.castShadow = true
    scene.add(mainLight)

    const fillLight = new THREE.DirectionalLight(0x8bb7ff, 0.3)
    fillLight.position.set(-5, 5, 5)
    scene.add(fillLight)

    controls = new OrbitControls(camera, renderer.domElement)
    controls.target.set(0, 1.4, 0)
    controls.update()

    const loader = new GLTFLoader()
    loader.register((parser) => new VRMLoaderPlugin(parser))
    try {
      const gltf = await loader.loadAsync('/models/riko.vrm')
      vrm = gltf.userData.vrm
      vrm.scene.rotation.y += Math.PI / 1
      vrm.scene.scale.set(2, 2, 2)
      vrm.scene.position.set(0, -2, -0.5)
      vrm.scene.castShadow = true
      vrm.scene.receiveShadow = true
      console.log(vrm.meta)
      startBlinking()
      VRMUtils.removeUnnecessaryJoints(vrm.scene)
      scene.add(vrm.scene)
      await loadDefaultAnimations()
    } catch (err) {
      console.warn('VRM model failed to load:', err)
    }

    clock = new THREE.Clock()
    animate()
    window.addEventListener('resize', onResize)
  })

  async function loadDefaultAnimations() {
    try {
      console.log('🎭 Auto-loading default animations...')
      const fbxLoader = new FBXLoader()

      // Load idle animation
      const idleAsset = await fbxLoader.loadAsync('/animations/HappyIdle.fbx')
      idleAnimation = await convertMixamoClip(
        THREE.AnimationClip.findByName(idleAsset.animations, 'mixamo.com') || idleAsset.animations[0],
        idleAsset,
        vrm,
      )
      console.log('✅ Idle animation loaded')

      // Load gesture animations (if available)
      try {
        const gestureFiles = [
          'Wave.fbx',
          'Shrug.fbx',
          'Pointing.fbx',
          'Clapping.fbx',
          'ThumbsUp.fbx'
        ]

        for (const file of gestureFiles) {
          try {
            const gestureAsset = await fbxLoader.loadAsync(`/animations/${file}`)
            const gestureName = file.replace('.fbx', '').toLowerCase()
            gestureAnimations[gestureName] = await convertMixamoClip(
              THREE.AnimationClip.findByName(gestureAsset.animations, 'mixamo.com') || gestureAsset.animations[0],
              gestureAsset,
              vrm,
            )
            console.log(`✅ ${gestureName} gesture loaded`)
          } catch (e) {
            console.warn(`⚠️ Could not load ${file}:`, e)
          }
        }
      } catch (e) {
        console.warn('⚠️ Some gesture animations could not be loaded:', e)
      }

      startIdleAnimation()
    } catch (error) {
      console.error('Error loading default animations:', error)
    }
  }

  async function convertMixamoClip(clip, asset, vrm) {
    const tracks = []
    const restRotationInverse = new THREE.Quaternion()
    const parentRestWorldRotation = new THREE.Quaternion()
    const _quatA = new THREE.Quaternion()
    const _vec3 = new THREE.Vector3()

    const motionHipsHeight = asset.getObjectByName('mixamorigHips').position.y
    const vrmHipsY = vrm.humanoid?.getNormalizedBoneNode('hips').getWorldPosition(_vec3).y
    const vrmRootY = vrm.scene.getWorldPosition(_vec3).y
    const vrmHipsHeight = Math.abs(vrmHipsY - vrmRootY)
    const hipsPositionScale = vrmHipsHeight / motionHipsHeight

    clip.tracks.forEach((track) => {
      const trackSplitted = track.name.split('.')
      const mixamoRigName = trackSplitted[0]
      const vrmBoneName = mixamoVRMRigMap[mixamoRigName]
      const vrmNodeName = vrm.humanoid?.getNormalizedBoneNode(vrmBoneName)?.name
      const mixamoRigNode = asset.getObjectByName(mixamoRigName)

      if (vrmNodeName != null) {
        const propertyName = trackSplitted[1]

        mixamoRigNode.getWorldQuaternion(restRotationInverse).invert()
        mixamoRigNode.parent.getWorldQuaternion(parentRestWorldRotation)

        if (track instanceof THREE.QuaternionKeyframeTrack) {
          for (let i = 0; i < track.values.length; i += 4) {
            const flatQuaternion = track.values.slice(i, i + 4)
            _quatA.fromArray(flatQuaternion)
            _quatA.premultiply(parentRestWorldRotation).multiply(restRotationInverse)
            _quatA.toArray(flatQuaternion)
            flatQuaternion.forEach((v, index) => {
              track.values[index + i] = v
            })
          }

          tracks.push(
            new THREE.QuaternionKeyframeTrack(
              `${vrmNodeName}.${propertyName}`,
              track.times,
              track.values.map((v, i) => (vrm.meta?.metaVersion === '0' && i % 2 === 0 ? -v : v)),
            ),
          )
        } else if (track instanceof THREE.VectorKeyframeTrack) {
          const value = track.values.map(
            (v, i) => (vrm.meta?.metaVersion === '0' && i % 3 !== 1 ? -v : v) * hipsPositionScale,
          )
          if (vrmBoneName === 'hips' && propertyName === 'position') {
            for (let i = 0; i < value.length; i += 3) {
              value[i] = 0
              value[i + 2] = 0
            }
          }
          tracks.push(
            new THREE.VectorKeyframeTrack(`${vrmNodeName}.${propertyName}`, track.times, value),
          )
        }
      }
    })

    return new THREE.AnimationClip('vrmAnimation', clip.duration, tracks)
  }

  function startIdleAnimation() {
    if (!vrm || !idleAnimation) return
    if (currentAnimationAction) {
      currentAnimationAction.stop()
    }
    currentMixer = new THREE.AnimationMixer(vrm.scene)
    currentAnimationAction = currentMixer.clipAction(idleAnimation)
    currentAnimationAction.setLoop(THREE.LoopRepeat)
    currentAnimationAction.reset()
    currentAnimationAction.play()
  }

  function animate() {
    if (!renderer || !camera || !scene) return
    const delta = clock?.getDelta() || 0
    vrm?.update(delta)
    controls?.update()
    if (currentMixer) {
      currentMixer.update(delta)
    }
    renderer.render(scene, camera)
    animationFrameId = requestAnimationFrame(animate)
  }

  function onResize() {
    camera.aspect = window.innerWidth / window.innerHeight
    camera.updateProjectionMatrix()
    renderer.setSize(window.innerWidth, window.innerHeight)
  }

  onBeforeUnmount(() => {
    cancelAnimationFrame(animationFrameId)
    renderer?.dispose()
    window.removeEventListener('resize', onResize)
    if (currentMixer) {
      currentMixer.stopAllAction()
    }
    if (audioCtx.value) {
      audioCtx.value.close()
    }
    if (blinkInterval) clearTimeout(blinkInterval)
    if (gestureTimeout) clearTimeout(gestureTimeout)
    try {
      sourceNode?.disconnect()
    } catch { /* empty */ }
    try {
      analyser.value?.disconnect()
    } catch { /* empty */ }
    sourceNode = null
    analyser.value = null
  })

  // --- Browser STT / Microphone ---
  const isRecording = ref(false)
  let recognition
  async function toggleRecording() {
    if (!isRecording.value) {
      if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
        console.error('SpeechRecognition API not supported')
        return
      }

      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
      recognition = new SpeechRecognition()
      recognition.lang = 'en-US'
      recognition.interimResults = false
      recognition.maxAlternatives = 1

      recognition.onresult = async (event) => {
        const transcript = event.results[0][0].transcript
        userInput.value = transcript
        await sendMessage()
      }

      recognition.onerror = (event) => {
        if (event.error === 'no-speech') {
          console.warn('No speech detected. Please try speaking clearly.')
        } else {
          console.error('SpeechRecognition error:', event.error)
        }
        isRecording.value = false
      }

      recognition.onend = () => {
        isRecording.value = false
      }

      recognition.start()
      isRecording.value = true
    } else {
      recognition.stop()
    }
  }

  // --- Chat / TTS ---
  async function sendMessage() {
    if (!userInput.value.trim()) return
    const reply = await gpt5Chat(userInput.value)
    const [audioDuration, animPlan] = await Promise.all([
      sovitsGen(reply),
      generateAnimationPlan(reply),
    ])

    // Scale animation timings to match audio duration
    const planTotal = animPlan.reduce((s, step) => s + step.duration, 0)
    if (planTotal > 0 && audioDuration > 0) {
      const scale = (audioDuration * 1000) / planTotal
      animPlan.forEach((step) => (step.duration = Math.round(step.duration * scale)))
    }

    animationQueue.value = animPlan
    playAnimation(animPlan)
    userInput.value = ''
    autoResize()
  }

  function autoResize() {
    const el = textareaRef.value
    if (el) {
      el.style.height = 'auto'
      el.style.height = el.scrollHeight + 'px'
    }
  }

  async function gpt5Chat(text) {
    try {
      const response = await gptClient.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [
          {
            role: 'user',
            parts: [{ text: `${charConfig?.presets?.default?.system_prompt}\n\nUser: ${text}` }],
          },
        ],
      })
      return response.candidates?.[0]?.content?.parts?.[0]?.text || '...no reply...'
    } catch (err) {
      console.error('Google Generative AI error:', err)
      return 'Sorry, senpai, something went wrong.'
    }
  }

  // --- SoVITS TTS ---
  async function sovitsGen(text) {
    try {
      const ttsUrl = 'http://127.0.0.1:9880/tts'
      const payload = {
        text,
        ref_audio_path: charConfig.sovits_ping_config?.ref_audio_path,
        text_lang: charConfig.sovits_ping_config?.text_lang || 'en',
        prompt_text: charConfig.sovits_ping_config?.prompt_text || '',
        prompt_lang: charConfig.sovits_ping_config?.prompt_lang || 'en',
        media_type: 'wav',
        streaming_mode: true,
      }
      const resp = await axios.post(ttsUrl, payload, {
        responseType: 'arraybuffer',
        headers: { 'Content-Type': 'application/json' },
      })
      const blob = new Blob([resp.data], { type: 'audio/wav' })
      const duration = await playBlob(blob)
      syncMouthToVoice(audioRef.value)
      return duration
    } catch (err) {
      console.error('SoVITS TTS error:', err)
      return 0
    }
  }

  async function playBlob(blob) {
    const audio = audioRef.value
    if (!audio) return 0
    try {
      audio.pause()
    } catch { /* empty */ }
    audio.src = ''
    audio.load()
    if (audioCtx.value && audioCtx.value.state !== 'running') {
      try {
        await audioCtx.value.resume()
      } catch { /* empty */ }
    }
    const url = URL.createObjectURL(blob)
    audio.src = url
    const playPromise = new Promise((resolve) => {
      audio.onplay = () => resolve()
    })
    await audio.play().catch((e) => {
      console.error('Audio play() failed:', e)
    })
    await playPromise
    return audio.duration
  }

  // --- Enhanced expression system ---
  function lerpExpression(expression, target, duration = 400) {
    if (!vrm?.expressionManager) return

    currentExpression.value = expression
    const expressions = EXPRESSIONS[expression] || [expression]

    expressions.forEach(expr => {
      const start = vrm.expressionManager.getValue(expr) || 0
      const startTime = performance.now()

      function step(now) {
        const t = Math.min((now - startTime) / duration, 1)
        const eased = t * (2 - t) // ease out
        const value = start + (target - start) * eased
        vrm.expressionManager.setValue(expr, value)
        vrm.expressionManager.update()
        if (t < 1) requestAnimationFrame(step)
      }
      requestAnimationFrame(step)
    })
  }

  // --- Enhanced head motion with more variety ---
  function animateHeadMotion(type, duration = 600) {
    if (!vrm) return
    const head = vrm.humanoid?.getNormalizedBoneNode('head')
    if (!head) return

    const startRot = head.rotation.clone()
    let targetRot = new THREE.Euler()
    let animationCurve = Math.sin // default curve

    switch (type) {
      case 'nod':
        targetRot.set(0.4, 0, 0)
        break
      case 'shake':
        targetRot.set(0, 0.4, 0)
        animationCurve = (t) => Math.sin(t * Math.PI * 2) * 0.5
        break
      case 'tiltLeft':
        targetRot.set(0, 0, 0.25)
        break
      case 'tiltRight':
        targetRot.set(0, 0, -0.25)
        break
      case 'lookUp':
        targetRot.set(-0.3, 0, 0)
        break
      case 'lookDown':
        targetRot.set(0.3, 0, 0)
        break
      case 'doubleNod':
        animationCurve = (t) => Math.sin(t * Math.PI * 4) * 0.5
        targetRot.set(0.3, 0, 0)
        duration *= 1.5
        break
      case 'confused':
        animationCurve = (t) => Math.sin(t * Math.PI * 3) * 0.3
        targetRot.set(0, 0.2, 0.1)
        break
    }

    const startTime = performance.now()
    function step(now) {
      const t = Math.min((now - startTime) / duration, 1)
      const eased = animationCurve(t * Math.PI)
      head.rotation.x = startRot.x + (targetRot.x - startRot.x) * eased
      head.rotation.y = startRot.y + (targetRot.y - startRot.y) * eased
      head.rotation.z = startRot.z + (targetRot.z - startRot.z) * eased
      if (t < 1) requestAnimationFrame(step)
      else head.rotation.copy(startRot)
    }
    requestAnimationFrame(step)
  }

  // --- Enhanced gesture system ---
  function performGesture(gestureType, duration = 1000) {
    if (!vrm || !gestureType || gestureType === 'none') return

    currentGesture.value = gestureType

    // Clear any existing gesture timeout
    if (gestureTimeout) clearTimeout(gestureTimeout)

    // Check if we have a loaded animation for this gesture
    if (gestureAnimations[gestureType]) {
      playGestureAnimation(gestureType)
      return
    }

    // Fallback to procedural gestures
    const leftArm = vrm.humanoid?.getNormalizedBoneNode('leftUpperArm')
    const rightArm = vrm.humanoid?.getNormalizedBoneNode('rightUpperArm')
    const leftForearm = vrm.humanoid?.getNormalizedBoneNode('leftLowerArm')
    const rightForearm = vrm.humanoid?.getNormalizedBoneNode('rightLowerArm')
    const spine = vrm.humanoid?.getNormalizedBoneNode('spine')

    if (!leftArm || !rightArm) return

    const startPositions = {
      leftArm: leftArm.rotation.clone(),
      rightArm: rightArm.rotation.clone(),
      leftForearm: leftForearm?.rotation.clone(),
      rightForearm: rightForearm?.rotation.clone(),
      spine: spine?.rotation.clone()
    }

    let gestureAnimation

    switch (gestureType) {
      case 'shrug':
        gestureAnimation = (t) => {
          const intensity = Math.sin(t * Math.PI) * 0.8
          leftArm.rotation.z = startPositions.leftArm.z + intensity
          rightArm.rotation.z = startPositions.rightArm.z - intensity
          leftArm.rotation.x = startPositions.leftArm.x - intensity * 0.3
          rightArm.rotation.x = startPositions.rightArm.x - intensity * 0.3
          if (spine) spine.rotation.y = Math.sin(t * Math.PI * 2) * 0.1
        }
        break

      case 'point':
        gestureAnimation = (t) => {
          const intensity = Math.sin(t * Math.PI) * 0.9
          rightArm.rotation.x = startPositions.rightArm.x - intensity * 1.2
          rightArm.rotation.z = startPositions.rightArm.z - intensity * 0.5
          if (rightForearm) rightForearm.rotation.x = intensity * 0.8
        }
        break

      case 'handWave':
        gestureAnimation = (t) => {
          const wave = Math.sin(t * Math.PI * 6) * 0.4
          const lift = Math.sin(t * Math.PI) * 1.2
          rightArm.rotation.x = startPositions.rightArm.x - lift
          rightArm.rotation.z = startPositions.rightArm.z - 0.8 + wave
          if (rightForearm) rightForearm.rotation.y = wave * 0.5
        }
        break

      case 'crossArms':
        gestureAnimation = (t) => {
          const intensity = Math.sin(t * Math.PI) * 0.7
          leftArm.rotation.y = startPositions.leftArm.y + intensity
          rightArm.rotation.y = startPositions.rightArm.y - intensity
          leftArm.rotation.x = startPositions.leftArm.x - intensity * 0.5
          rightArm.rotation.x = startPositions.rightArm.x - intensity * 0.5
        }
        break

      case 'handToHeart':
        gestureAnimation = (t) => {
          const intensity = Math.sin(t * Math.PI) * 0.8
          rightArm.rotation.x = startPositions.rightArm.x - intensity * 0.8
          rightArm.rotation.y = startPositions.rightArm.y + intensity * 0.4
          rightArm.rotation.z = startPositions.rightArm.z + intensity * 0.3
        }
        break

      case 'think':
        gestureAnimation = (t) => {
          const intensity = Math.sin(t * Math.PI) * 0.6
          rightArm.rotation.x = startPositions.rightArm.x - intensity * 1.1
          rightArm.rotation.y = startPositions.rightArm.y + intensity * 0.2
          if (rightForearm) rightForearm.rotation.x = intensity * 1.2
          animateHeadMotion('tiltLeft', duration * 0.8)
        }
        break

      case 'stretch':
        gestureAnimation = (t) => {
          const intensity = Math.sin(t * Math.PI) * 1.0
          leftArm.rotation.x = startPositions.leftArm.x - intensity * 1.5
          rightArm.rotation.x = startPositions.rightArm.x - intensity * 1.5
          leftArm.rotation.z = startPositions.leftArm.z + intensity * 0.8
          rightArm.rotation.z = startPositions.rightArm.z - intensity * 0.8
          if (spine) spine.rotation.x = startPositions.spine.x - intensity * 0.2
        }
        break

      case 'facepalm':
        gestureAnimation = (t) => {
          const intensity = Math.sin(t * Math.PI) * 0.9
          rightArm.rotation.x = startPositions.rightArm.x - intensity * 1.3
          rightArm.rotation.y = startPositions.rightArm.y + intensity * 0.3
          if (rightForearm) rightForearm.rotation.x = intensity * 1.0
          animateHeadMotion('lookDown', duration * 0.6)
        }
        break

      case 'thumbsUp':
        gestureAnimation = (t) => {
          const intensity = Math.sin(t * Math.PI) * 0.8
          rightArm.rotation.x = startPositions.rightArm.x - intensity * 0.8
          rightArm.rotation.z = startPositions.rightArm.z - intensity * 0.4
          if (rightForearm) rightForearm.rotation.x = intensity * 0.6
        }
        break

      case 'clap':
        gestureAnimation = (t) => {
          const clap = Math.sin(t * Math.PI * 8) > 0 ? 1 : 0
          const baseIntensity = Math.sin(t * Math.PI) * 0.7
          leftArm.rotation.x = startPositions.leftArm.x - baseIntensity
          rightArm.rotation.x = startPositions.rightArm.x - baseIntensity
          leftArm.rotation.y = startPositions.leftArm.y + (baseIntensity + clap * 0.3)
          rightArm.rotation.y = startPositions.rightArm.y - (baseIntensity + clap * 0.3)
        }
        break

      default:
        return
    }

    const startTime = performance.now()
    function step(now) {
      const t = Math.min((now - startTime) / duration, 1)
      gestureAnimation(t)

      if (t < 1) {
        requestAnimationFrame(step)
      } else {
        // Reset to original positions
        leftArm.rotation.copy(startPositions.leftArm)
        rightArm.rotation.copy(startPositions.rightArm)
        if (leftForearm) leftForearm.rotation.copy(startPositions.leftForearm)
        if (rightForearm) rightForearm.rotation.copy(startPositions.rightForearm)
        if (spine) spine.rotation.copy(startPositions.spine)
        currentGesture.value = 'none'
      }
    }
    requestAnimationFrame(step)
  }

  function playGestureAnimation(gestureType) {
    if (!currentMixer || !gestureAnimations[gestureType]) return

    const gestureAction = currentMixer.clipAction(gestureAnimations[gestureType])
    gestureAction.setLoop(THREE.LoopOnce)
    gestureAction.clampWhenFinished = true
    gestureAction.reset()
    gestureAction.play()

    gestureTimeout = setTimeout(() => {
      gestureAction.fadeOut(0.5)
      currentGesture.value = 'none'
    }, gestureAnimations[gestureType].duration * 1000)
  }

  // --- Improved mouth sync with multiple phonemes ---
  function syncMouthToVoice(audioElement) {
    if (!vrm || !vrm.expressionManager || !audioCtx.value || !audioElement) return
    if (!sourceNode) {
      sourceNode = audioCtx.value.createMediaElementSource(audioElement)
    }
    if (mouthRaf) cancelAnimationFrame(mouthRaf)
    if (analyser.value) analyser.value.disconnect()

    analyser.value = audioCtx.value.createAnalyser()
    analyser.value.fftSize = 2048
    analyser.value.smoothingTimeConstant = 0.3

    const bufferLength = analyser.value.fftSize
    const dataArray = new Uint8Array(bufferLength)
    const frequencyData = new Uint8Array(analyser.value.frequencyBinCount)

    try {
      sourceNode.disconnect()
    } catch { /* empty */ }
    sourceNode.connect(analyser.value)
    analyser.value.connect(audioCtx.value.destination)

    let prevEnergy = 0
    let prevHighFreq = 0

    const tick = () => {
      analyser.value.getByteTimeDomainData(dataArray)
      analyser.value.getByteFrequencyData(frequencyData)

      // Calculate RMS energy
      let sumSquares = 0
      for (let i = 0; i < bufferLength; i++) {
        const val = (dataArray[i] - 128) / 128
        sumSquares += val * val
      }
      const rms = Math.sqrt(sumSquares / bufferLength)

      // Calculate high frequency content for different mouth shapes
      let highFreqSum = 0
      for (let i = Math.floor(frequencyData.length * 0.3); i < frequencyData.length; i++) {
        highFreqSum += frequencyData[i]
      }
      const highFreq = highFreqSum / (frequencyData.length * 0.7) / 255

      // Smooth the values
      const smoothed = prevEnergy * 0.7 + rms * 0.3
      const smoothedHigh = prevHighFreq * 0.8 + highFreq * 0.2
      prevEnergy = smoothed
      prevHighFreq = smoothedHigh

      // Map to different mouth shapes
      const mouthOpen = Math.min(Math.max(smoothed * 8, 0), 1)
      const mouthWide = Math.min(smoothedHigh * 2, 1)
      const mouthSmile = Math.min(smoothedHigh * 1.5, 0.5)

      // Apply smoothing to existing values
      const curAA = vrm.expressionManager.getValue('aa') || 0
      const curEE = vrm.expressionManager.getValue('ee') || 0
      const curOH = vrm.expressionManager.getValue('oh') || 0
      const curSmile = vrm.expressionManager.getValue('happy') || 0

      vrm.expressionManager.setValue('aa', curAA + (mouthOpen - curAA) * 0.3)
      vrm.expressionManager.setValue('ee', curEE + (mouthWide - curEE) * 0.25)
      vrm.expressionManager.setValue('oh', curOH + ((mouthOpen * 0.6) - curOH) * 0.2)
      vrm.expressionManager.setValue('happy', curSmile + (mouthSmile - curSmile) * 0.1)
      vrm.expressionManager.update()

      if (!audioElement.paused && !audioElement.ended) {
        mouthRaf = requestAnimationFrame(tick)
      } else {
        // Gradually close mouth
        const resetMouth = () => {
          const aa = vrm.expressionManager.getValue('aa') || 0
          const ee = vrm.expressionManager.getValue('ee') || 0
          const oh = vrm.expressionManager.getValue('oh') || 0
          const smile = vrm.expressionManager.getValue('happy') || 0

          if (aa > 0.01 || ee > 0.01 || oh > 0.01 || smile > 0.01) {
            vrm.expressionManager.setValue('aa', Math.max(aa * 0.9, 0))
            vrm.expressionManager.setValue('ee', Math.max(ee * 0.9, 0))
            vrm.expressionManager.setValue('oh', Math.max(oh * 0.9, 0))
            vrm.expressionManager.setValue('happy', Math.max(smile * 0.95, 0))
            vrm.expressionManager.update()
            requestAnimationFrame(resetMouth)
          }
        }
        resetMouth()
        mouthRaf = null
      }
    }
    tick()
  }

  // --- Enhanced blinking system ---
  function startBlinking() {
    if (!vrm || !vrm.expressionManager) return
    if (blinkInterval) clearTimeout(blinkInterval)

    const doBlink = () => {
      if (!vrm?.expressionManager) return

      // Randomize blink intensity and duration
      const intensity = 0.8 + Math.random() * 0.2
      const duration = 120 + Math.random() * 80

      vrm.expressionManager.setValue('blink', intensity)
      vrm.expressionManager.update()

      setTimeout(() => {
        vrm.expressionManager.setValue('blink', 0.0)
        vrm.expressionManager.update()

        // Random next blink time (2-6 seconds)
        const nextBlink = 2000 + Math.random() * 4000
        blinkInterval = setTimeout(doBlink, nextBlink)
      }, duration)
    }
    doBlink()
  }

  // --- Enhanced drag and drop with better error handling ---
  window.addEventListener('drop', async (e) => {
    e.preventDefault()
    const file = e.dataTransfer.files[0]
    if (file && file.name.endsWith('.vrm')) {
      try {
        console.log('Loading new VRM model:', file.name)
        const arrayBuffer = await file.arrayBuffer()
        const loader = new GLTFLoader()
        loader.register((parser) => new VRMLoaderPlugin(parser))
        const gltf = await loader.parseAsync(arrayBuffer, '', file.name)

        // Clean up old model
        if (vrm) {
          scene.remove(vrm.scene)
          vrm.scene.traverse((child) => {
            if (child.isMesh) {
              child.geometry?.dispose()
              if (Array.isArray(child.material)) {
                child.material.forEach((m) => m.dispose())
              } else {
                child.material?.dispose()
              }
            }
          })
        }

        // Setup new model
        vrm = gltf.userData.vrm
        vrm.scene.scale.set(2, 2, 2)
        vrm.scene.position.set(0, -2, -0.5)
        vrm.scene.rotation.y = Math.PI
        vrm.scene.castShadow = true
        vrm.scene.receiveShadow = true
        scene.add(vrm.scene)
        VRMUtils.removeUnnecessaryJoints(vrm.scene)

        // Restart animations
        startBlinking()
        await loadDefaultAnimations()
        startIdleAnimation()

        console.log('✅ New VRM model loaded successfully')
      } catch (error) {
        console.error('❌ Failed to load VRM model:', error)
      }
    }
  })

  window.addEventListener('dragover', (e) => e.preventDefault())

  // --- Enhanced Animation JSON Generator ---
  async function generateAnimationPlan(text) {
    const animPrompt = {
      role: 'user',
      parts: [
        {
          text: `
  You are an advanced animation director for a VRM character with extensive animation capabilities.
  Analyze the following text and create a detailed animation sequence.

  ⚠️ Return ONLY valid JSON (array of objects). Do not include explanations or code fences.

  Available expressions: neutral, happy, sad, angry, surprised, excited, confused, smirk, laugh, embarrassed, determined, worried, curious, sleepy, mischievous

  Available head motions: none, nod, shake, tiltLeft, tiltRight, lookUp, lookDown, doubleNod, confused

  Available gestures: none, point, handWave, shrug, leanIn, crossArms, handToHeart, thumbsUp, facepalm, handToHip, stretch, clap, think, dance, talk, idle

  SPECIAL GESTURES:
  - dance: Triggers the Bling-Bang-Bang-Born dance animation (10+ seconds)
  - talk: Uses talking animation during speech
  - idle: Returns to happy idle animation

  Each object MUST have:
  - "text": the spoken phrase/sentence,
  - "expression": choose the most appropriate expression,
  - "headMotion": choose appropriate head movement,
  - "gesture": choose appropriate gesture (use dance for celebratory moments, talk for conversations),
  - "duration": milliseconds for this animation step,
  - "intensity": 0.1-1.0 for animation strength

  Consider:
  - Use "dance" gesture for celebratory, fun, or energetic responses
  - Use "talk" gesture during normal conversation
  - Match expressions to emotional content
  - Use gestures for emphasis, not every phrase
  - Vary head motions naturally
  - Time animations to speech rhythm
  - Use lower intensity for subtle moments

  Text to animate:
  """${text}"""
  `,
        },
      ],
    }

    try {
      const response = await gptClient.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [animPrompt],
      })
      let raw = response.candidates?.[0]?.content?.parts?.[0]?.text || '[]'
      raw = raw
        .replace(/```json/g, '')
        .replace(/```/g, '')
        .trim()
      const plan = JSON.parse(raw)
      console.log('Generated animation plan:', plan)
      return plan
    } catch (err) {
      console.error('Animation JSON error:', err)
      // Fallback simple plan
      return [{
        text: text,
        expression: 'neutral',
        headMotion: 'none',
        gesture: 'none',
        duration: 2000,
        intensity: 0.5
      }]
    }
  }

  // --- Enhanced animation playback system with smoother timing ---
  async function playAnimation(plan) {
    if (!vrm || !vrm.expressionManager || !plan.length) return

    console.log('Playing smooth animation sequence:', plan.length, 'steps')

    for (let i = 0; i < plan.length; i++) {
      const step = plan[i]
      const intensity = (step.intensity || 0.7) * 0.6 // Reduce overall intensity for subtlety

      console.log(`Animation step ${i + 1}:`, step)

      // Start animations with overlapping timing for natural flow
      const animations = []
      const transitionTime = 600 // Longer transition time

      // Expression animation with smoother blending
      if (step.expression && step.expression !== 'neutral') {
        animations.push(
          new Promise((resolve) => {
            lerpExpression(step.expression, intensity, transitionTime)
            setTimeout(resolve, transitionTime * 0.3) // Allow overlap
          })
        )
      }

      // Head motion with reduced intensity
      if (step.headMotion && step.headMotion !== 'none') {
        animations.push(
          new Promise((resolve) => {
            animateHeadMotion(step.headMotion, Math.min(step.duration * 1.2, 1200))
            setTimeout(resolve, 200)
          })
        )
      }

      // Gesture with careful timing
      if (step.gesture && step.gesture !== 'none') {
        animations.push(
          new Promise((resolve) => {
            performGesture(step.gesture, Math.min(step.duration * 1.5, 2000))
            setTimeout(resolve, 300)
          })
        )
      }

      // Wait for step duration with smoother pacing
      const stepDuration = Math.max(step.duration, 800) // Minimum duration for smoothness
      await Promise.all([
        ...animations,
        new Promise(r => setTimeout(r, stepDuration))
      ])

      // Fade out expression more gradually
      if (step.expression && step.expression !== 'neutral') {
        lerpExpression(step.expression, 0.0, transitionTime * 1.2) // Longer fade out
      }

      // Longer pause between steps for natural rhythm
      if (i < plan.length - 1) {
        await new Promise(r => setTimeout(r, 200 + Math.random() * 200)) // Random pause for naturalness
      }
    }

    console.log('Smooth animation sequence complete')
    animationQueue.value = []
  }
  </script>
